package com.drawing.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

public class Drawing extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
	Sprite character;
	private static int SPEED = 3;
	int x = 0;
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		img = new Texture("images.png");
		character = new Sprite(img);
	}

	@Override
	public void render () {
		if(Gdx.input.isKeyPressed(Input.Keys.LEFT)) character.translateX(-SPEED);
		if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)) character.translateX(SPEED);
		if(Gdx.input.isKeyPressed(Input.Keys.UP)) character.translateY(SPEED);
		if(Gdx.input.isKeyPressed(Input.Keys.DOWN)) character.translateY(-SPEED);
		if(Gdx.input.isTouched()) character.setPosition(Gdx.input.getX(), Gdx.graphics.getHeight() - Gdx.input.getY());
		ScreenUtils.clear(255, 255, 255, 1);
		batch.begin();
		batch.draw(character, character.getX(), character.getY());
		batch.end();
	}

	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}
}
